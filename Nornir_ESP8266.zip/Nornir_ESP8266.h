/*
 Name:		Nornir_ESP8266.h
 Created:	8/16/2017 12:00:14 PM
 Author:	NPLoh
 Editor:	http://www.visualmicro.com
*/

#ifndef _Nornir_ESP8266_h
#define _Nornir_ESP8266_h

#include <Arduino.h>
#include <vector>
#include <ESP8266WiFiMulti.h>
#include <ESP8266HTTPClient.h>
#include <ESP8266WebServer.h>
#include <EEPROM.h>

// - WiFi



/*
const String wifi_ssid = "657-Oslo";
const String wifi_password = "coworking657";

// - RTW
const String objectId = "1";
const String username = "demo5";
const String password = "12345";
const String login = "objectID=" + objectId + "&username=" + username + "&password=" + password;

const String domain = "nursepad.rtw.no";
const String service = "accelerometer";
const String host = "http://" + domain + "/" + service;


*/



// Structure for RTW Data
struct RTW_data_t {
	String tag;
	String data;	
};

// RTW Message Class
class RTW_message {
	public:
		int size;
		RTW_data_t *RTW_data;
		
		// Constructor
		RTW_message(String received_data)
		{
			// Find Size
			int start_bracket, end_bracket = 0;
			size = 0;
			while (true) 
			{
				start_bracket = received_data.indexOf('<', end_bracket);
				end_bracket = received_data.indexOf('>', end_bracket + 1);
		
				if (start_bracket == -1 || end_bracket == -1)
				{
					break;
				}
		
				String tag = received_data.substring(start_bracket + 1, end_bracket);
		
				if (tag != "RTW" && tag.charAt(0) != '/')
				{
					start_bracket = received_data.indexOf('<', end_bracket);
					end_bracket = received_data.indexOf('>', end_bracket + 1);
					size++;
				}
			}
		
			RTW_data = new RTW_data_t[size];
		
			start_bracket = received_data.indexOf('<');
			end_bracket = received_data.indexOf('>');
		
			// Fill Data
			for (int i = 0; i < size; i++)
			{
				start_bracket = received_data.indexOf('<', end_bracket);
				end_bracket = received_data.indexOf('>', end_bracket + 1);	
				RTW_data[i].tag =  received_data.substring(start_bracket + 1, end_bracket);
		
				start_bracket = received_data.indexOf('<', end_bracket);
				RTW_data[i].data = received_data.substring(end_bracket + 1, start_bracket);
				end_bracket = received_data.indexOf('>', end_bracket + 1);
				
				Serial.println("Tag: " + RTW_data[i].tag + " Data: " + RTW_data[i].data);
			}
		};

		// Destructor
		~RTW_message()
		{
			delete [] RTW_data;
		};
};

/*
class RTW_received_t {
	public: 
		int size;
		RTW_data_t *RTW_data;

		RTW_received_t(String received_data);
}
*/

String RTW_data2string(RTW_data_t* RTW_data, int size);


// Send & Get
int RTW_send_data(String host, String data);
int RTW_get_data(String host, String login, void (*rtw_callback)(String), void (*loop_callback)());

// - SERVER Functions
void config_server();
void handle_server();
String build_web_page();

#endif