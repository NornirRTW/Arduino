#include "Nornir_ESP8266.h"

int RTW_send_data(String host, String data)
{
	// Create Object and Begin Session
	HTTPClient http;
	http.begin(host);

	http.addHeader("Content-Type", "application/x-www-form-urlencoded");
	// RTW SPESIFIC------------------------------------------------------------------------------------
	http.addHeader("Synx-Cat", "1");	// Synx Category 1, Send Data
	// RTW SPESIFIC------------------------------------------------------------------------------------

	// Post HTTP, http_codes are found in ESP8266HTTPClient.h
	int http_code = http.POST(data);	

	// End HTTP Session
	http.end();

	// Return
	if (http_code == HTTP_CODE_OK)
	{
		Serial.println("[HTTP] POST: Sucess");
		return 0;
	}
	else
	{
		Serial.printf("[HTTP] POST: Error %d\n", http_code);
		return 1;
	}
}

int RTW_get_data(String host, String login, void (*rtw_callback)(String), void (*loop_callback)())
{
	Serial.println(host);
	Serial.println(login);
	// Create Object and Begin Session
	HTTPClient http;
	http.begin(host);

	// Add Headers
	http.addHeader("Connection", "keep-alive");
	http.addHeader("Content-Type", "application/x-www-form-urlencoded");
	// RTW SPESIFIC------------------------------------------------------------------------------------
	http.addHeader("Synx-Cat", "4");	// Synx Category 4, Receive Data
	// RTW SPESIFIC------------------------------------------------------------------------------------
	
	// Post HTTP, http_codes are found in ESP8266HTTPClient.h
	int http_code = http.POST(login);	
	
	if (http_code == HTTP_CODE_OK)
	{
		Serial.println("[HTTP] POST: Sucess");

		// Get Stream Pointer
		WiFiClient *stream = http.getStreamPtr();

		// Listen
		while (http.connected())
		{
			// Perform Loop function
			if (loop_callback != NULL)
			{
				loop_callback();
			}

			// Available Data
			size_t stream_size = stream->available();
			if(stream_size)
			{
				// Read Buffer
				char message[stream_size];

				// Read Bytes
				stream->readBytes(message, stream_size);

				// Convert to String and Parse
				String received_data = (char *)message;
				if (rtw_callback != NULL)
				{
					rtw_callback(received_data);
				}
			}
		}
	
		// End HTTP Session
		http.end();
		Serial.print("[HTTP] Connection Closed\n");
	}
	else
	{
		Serial.printf("[HTTP] POST: Error %d\n", http_code);
	}
}

String RTW_data2string(RTW_data_t* RTW_data, int size)
{
	String data_string = "";
	
	for (int i = 0; i < size; i++)
	{
		data_string += "&" + RTW_data[i].tag + "=" + RTW_data[i].data;
	}

	return data_string;
}


/////////////////////////////////////////////////////////////////
/*
// RTW Server
ESP8266WebServer server(80);

// Configure Server
void config_server()
{
	// Configure Server
	server.on("/", []()
	{
		build_web_page();
		server.send(200, "text/html", build_web_page());
	});
	
	server.on("/save_wifi", []()
	{
		if (server.hasArg("ssid") && server.hasArg("password"))
		{	
			wifi_ssid = server.arg("ssid");
			wifi_password = server.arg("password");

			build_web_page();
			server.send(200, "text/html", build_web_page());
		}
	});
	
	server.on("/save_rtw", []()
	{
		if (server.hasArg("domain") && server.hasArg("service"))
		{
			domain = server.arg("domain");
			service = server.arg("service");
			server.send(200, "text/html", build_web_page());
		}
	});
	
	server.begin();
	Serial.println("HTTP server started");
}

void handle_server()
{
	server.handleClient();
}

// Build Web Page
String build_web_page()
{
	String web_page = R"(
	<!DOCTYPE html>
	<html><head>
		<title>RTW Config</title>
	</head>
	<style>
	body {background-color: #202020}
	</style>
	<body>
		<img src="https://static.wixstatic.com/media/91c2ed_0a7c98d6e00d4881a964dc291d93dbd2~mv2_d_3144_1461_s_2.png/v1/fill/w_148,h_69,al_c,usm_0.66_1.00_0.01/91c2ed_0a7c98d6e00d4881a964dc291d93dbd2~mv2_d_3144_1461_s_2.png" alt="Nornir">
		<form action="/save_wifi" method="post">
		<fieldset>
		<legend> <font color="white"> WiFi Configuration </font> </legend>
			<font color="white"> SSID: </font> <br />
			<input style type="text" name="ssid" value=)" + wifi_ssid + R"( /> <br />   
			<font color="white"> Password: </font> <br />
			<input type="text" name="password" value=)" + wifi_password + R"( /> <br />
			<br />
			<input type="submit" value="Save" />
		</fieldset>
		</form>
		<br />
		<form action= "/save_rtw" method="post">
		<fieldset>
		<legend><font color="white"> RTW Configuration </font> </legend>
			<font color="white"> Domain: </domain> <br />
			<input type="text" name="domain" value=)" + domain + R"( /> <br />  
			<font color="white"> Service: </domain> <br />
			<input type="text" name="service" value=)" + service + R"( /> <br />
			<br />
			<input type="submit" value="Save" />
		</fieldset>
		</form>
	</body></html>
	)";

	return web_page;
}
*/